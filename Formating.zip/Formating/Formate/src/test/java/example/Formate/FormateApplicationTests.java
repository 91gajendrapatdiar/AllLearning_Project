package example.Formate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormateApplicationTests {

	@Test
	void contextLoads() {
	}

}
