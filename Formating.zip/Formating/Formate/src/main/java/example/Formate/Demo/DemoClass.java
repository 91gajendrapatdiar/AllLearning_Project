package example.Formate.Demo;


import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class DemoClass {

    @GetMapping("/convert")
    public ResponseEntity<String> convertJson() {
        String jsonContent;
        try {
            jsonContent = readJsonFromFile("DataJson.json");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error reading JSON file: " + e.getMessage());
        }

        try {
            JSONObject inputJson = new JSONObject(jsonContent);
            JSONObject outputJson = convertJsonData(inputJson);
            String formattedJson = outputJson.toString(2);
            System.out.println(formattedJson);
            return ResponseEntity.ok(formattedJson);
        } catch (JSONException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid JSON format: " + e.getMessage());
        } catch (ParseException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid date format: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred: " + e.getMessage());
        }
    }

    private String readJsonFromFile(String filename) throws IOException {
        ClassPathResource resource = new ClassPathResource("DataJson.json");
        try (InputStream inputStream = resource.getInputStream()) {
            return IOUtils.toString(inputStream, "UTF-8");
        }
    }
	   
	   
    private JSONObject convertJsonData(JSONObject inputJson) throws ParseException, JSONException {
        String pol = inputJson.getString("pol");
        String pod = inputJson.getString("pod");
        JSONArray sailingVoyList = inputJson.getJSONArray("sailingVoyList");

        JSONObject outputJson = new JSONObject();
        outputJson.put("pol", pol);
        outputJson.put("pod", pod);

        Map<String, List<JSONObject>> calendarMap = new HashMap<>();

        for (int i = 0; i < sailingVoyList.length(); i++) {
            JSONObject voyage = sailingVoyList.getJSONObject(i);
            String loadingPortArrival = voyage.has("iSequenceNo") ? voyage.getString("loadingPortArrival") : voyage.getString("loadingPortDeparture");

            SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd/MM/yyyy");
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM-dd"); // ISO 8601 format
            loadingPortArrival = outputDateFormat.format(inputDateFormat.parse(loadingPortArrival));

            if (!calendarMap.containsKey(loadingPortArrival)) {
                calendarMap.put(loadingPortArrival, new ArrayList<>());
            }
            calendarMap.get(loadingPortArrival).add(voyage);
        }

        JSONArray calendarArray = new JSONArray();
        for (Map.Entry<String, List<JSONObject>> entry : calendarMap.entrySet()) {
            String loadingPortArrivalDate = entry.getKey();
            List<JSONObject> voyages = entry.getValue();

            JSONObject calendarEntry = new JSONObject();
            calendarEntry.put("loadingPortArrival", loadingPortArrivalDate);

            JSONArray sailingHeaderArray = new JSONArray();
            Map<String, JSONObject> sailingHeaderMap = new HashMap<>();

            for (JSONObject voyage : voyages) {
                String referenceNo = voyage.getString("referenceNo");
                String finalArrivalTime = voyage.getString("finalArrivalTime");

                if (!sailingHeaderMap.containsKey(referenceNo + finalArrivalTime)) {
                    JSONObject sailingHeader = new JSONObject();
                    sailingHeader.put("voyNo", voyage.getString("voyNo"));
                    sailingHeader.put("vesselNameNo", voyage.getString("vesselNameNo"));
                    sailingHeader.put("pol", pol);
                    sailingHeader.put("pod", pod);
                    sailingHeader.put("loadingPortArrival", voyage.getString("loadingPortArrival"));
                    sailingHeader.put("destinationArrival", voyage.getString("destinationArrival"));
                    sailingHeader.put("referenceNo", referenceNo);
                    sailingHeader.put("finalArrivalTime", finalArrivalTime);
                    sailingHeader.put("sailingDetail", new JSONArray());
                    sailingHeaderMap.put(referenceNo + finalArrivalTime, sailingHeader);
                    sailingHeaderArray.put(sailingHeader);
                }

                JSONObject sailingDetail = new JSONObject();
                sailingDetail.put("voyNo", voyage.getString("voyNo"));
                sailingDetail.put("vesselNameNo", voyage.getString("vesselNameNo"));
                sailingDetail.put("transitTime", voyage.getString("transitTime"));
                sailingDetail.put("vesselFlag", voyage.getString("vesselFlag"));
                sailingDetail.put("loadingPortArrival", voyage.getString("loadingPortArrival"));
                sailingDetail.put("loadingPortDeparture", voyage.getString("loadingPortDeparture"));
                sailingDetail.put("destinationArrival", voyage.getString("destinationArrival"));
                sailingDetail.put("iSequenceNo", voyage.has("iSequenceNo") ? voyage.getString("iSequenceNo") : "");
                sailingDetail.put("loadPortArrival", voyage.getString("loadPortArrival"));
                sailingDetail.put("loadPortDeparture", voyage.getString("loadPortDeparture"));

                sailingHeaderMap.get(referenceNo + finalArrivalTime).getJSONArray("sailingDetail").put(sailingDetail);
            }

            calendarEntry.put("sailingHeader", sailingHeaderArray);
            calendarArray.put(calendarEntry);
        }

        outputJson.put("calendar", calendarArray);
        return outputJson;
    }
}
