package example.Formate.Demo; // Package declaration

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormateApplication {

    public static void main(String args) {
        SpringApplication.run(FormateApplication.class, args);
    }
}